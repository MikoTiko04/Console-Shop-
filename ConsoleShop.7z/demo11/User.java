package com.example.demo11;

 public class User {
    private String login;
    private String pass;
    private Basket basket;

    public User(String login, String pass) {
        this.login = login;
        this.pass = pass;
        this.basket = new Basket();
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public Basket getBasket() {
        return basket;
    }

    public void setBasket(Basket basket) {
        this.basket = basket;
    }
}
