package com.example.demo11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
//Tangirbergen Merei IT1-2208 LAB6 OOP


class Product {
    private String name;
    private double price;
    private int rating;

    public Product(String name, double price, int rating) {
        this.name = name;
        this.price = price;
        this.rating = rating;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}

class Category {
    private String name;
    private ArrayList<Product> products;

    public Category(String name) {
        this.name = name;
        this.products = new ArrayList<>();
    }

    void removeProduct(Product product) {
        this.products.remove(product);
    }


    public void addProduct(Product product) {
        products.add(product);
    }


    public String getName() {

        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }


    public void sortProducts() {
        for (int i = 0; i < products.size() - 1; i++) {
            for (int j = 0; j < products.size() - i - 1; j++) {
                if (products.get(j).getRating() < products.get(j + 1).getRating()) {
                    Product temp = products.get(j);
                    products.set(j, products.get(j + 1));
                    products.set(j + 1, temp);
                }
            }
        }
    }

}


    class Store {

        private ArrayList<Category> categories;

        public Store() {
            this.categories = new ArrayList<>();
        }

        public void addCategory(Category category) {
            categories.add(category);
        }

        public void removeCategory(Category category) {
            categories.remove(category);
        }

        public ArrayList<Category> getCategories() {
            return categories;
        }

        public void setCategories(ArrayList<Category> categories) {
            this.categories = categories;
        }

        public ArrayList<Product> search(String query) {
            ArrayList<Product> results = new ArrayList<>();

            for (Category category : categories) {
                if (category.getName().toLowerCase().contains(query.toLowerCase())) {
                    results.addAll(category.getProducts());
                    continue;
                }

                for (Product product : category.getProducts()) {
                    if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                        results.add(product);
                    } else {
                        String priceString = String.valueOf(product.getPrice());
                        if (priceString.contains(query)) {
                            results.add(product);
                        }
                    }
                }
            }

            return results;
        }


        public ArrayList<Product> filterByPrice(double minPrice, double maxPrice) {
            ArrayList<Product> results = new ArrayList<>();

            for (Category category : categories) {
                for (Product product : category.getProducts()) {
                    if (product.getPrice() >= minPrice && product.getPrice() <= maxPrice) {
                        results.add(product);
                    }
                }
            }

            return results;
        }

        public void sortProducts(ArrayList<Product> products, String sortBy) {
            Comparator<Product> comparator;

            switch (sortBy.toLowerCase()) {
                case "price":
                    comparator = Comparator.comparing(Product::getPrice);
                    break;
                case "rating":
                    comparator = Comparator.comparing(Product::getRating);
                    break;
                default:
                    comparator = Comparator.comparing(Product::getName);
            }

            products.sort(comparator);
        }


        public ArrayList<Product> filterByRating(int minRating, int maxRating) {
            ArrayList<Product> results = new ArrayList<>();

            for (Category category : categories) {
                for (Product product : category.getProducts()) {
                    if (product.getRating() >= minRating && product.getRating() <= maxRating) {
                        results.add(product);
                    }
                }
            }

            return results;
        }


    }




class Basket {
    private ArrayList<Product> products;

    public Basket() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public ArrayList<Product> getProducts() {
        return products;
    }
    public void removeProduct(Product product) {
        products.remove(product);
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
}

public class Technomarket {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Store store = new Store();


        Category phonesCategory = new Category("Phones");

        phonesCategory.addProduct(new Product("Iphone", 1500.0, 5));
        phonesCategory.addProduct(new Product("Oppo", 200.0, 3));
        phonesCategory.addProduct(new Product("Samsung", 1150.0, 5));
        phonesCategory.addProduct(new Product("Huawei", 500.0, 4));
        phonesCategory.addProduct(new Product("Nokia S35", 300.0, 4));

        store.addCategory(phonesCategory);

        Category laptopsCategory = new Category("Laptops");

        laptopsCategory.addProduct(new Product("ASUS TUF F 15", 1200.0, 5));
        laptopsCategory.addProduct(new Product("Lenovo Legion 7", 2000.0, 4));
        laptopsCategory.addProduct(new Product("HP Turbo 8", 900.0, 3));
        laptopsCategory.addProduct(new Product("Acer Nitro 9", 1600.0, 4));
        laptopsCategory.addProduct(new Product("Lenovo IDEA PAD 7", 800.0, 3));

        store.addCategory(laptopsCategory);

        Category accessoriesCategory = new Category("Accessories");

        accessoriesCategory.addProduct(new Product("Cases", 10.0, 2));
        accessoriesCategory.addProduct(new Product("Cables", 70.0, 1));
        accessoriesCategory.addProduct(new Product("Minutiae", 5.0, 3));
        accessoriesCategory.addProduct(new Product("Headphones", 200.0, 5));
        accessoriesCategory.addProduct(new Product("Smart watches", 300.0, 4));

        store.addCategory(accessoriesCategory);


        Category additionCategory = new Category("Addition");
        additionCategory.addProduct(new Product("870 EVO SATA 2.5 SSD 1TB", 94.0, 5));
        additionCategory.addProduct(new Product("KC3000 PCIe 4.0 NVMe M.2 SSD 1TB", 99.0, 5));
        additionCategory.addProduct(new Product("Crucial BX500 SSD 1TB", 74.0, 5));
        additionCategory.addProduct(new Product("Crucial MX500 SSD 1TB", 39.0, 3));
        additionCategory.addProduct(new Product("Crucial T500 SSD 1TB", 59.0, 4));

        store.addCategory(additionCategory);

        Category TVCategory = new Category("TV");
        TVCategory.addProduct(new Product("LG Super Smart TV", 1500.0, 5));
        TVCategory.addProduct(new Product("Samsung Super Smart TV", 1780.0, 5));
        TVCategory.addProduct(new Product("OLED Ultra 4k HD TV", 1400.0, 5));
        TVCategory.addProduct(new Product("Huawei Super HD TV", 499.0, 4));
        TVCategory.addProduct(new Product("LG Super HD TV", 599.0, 4));

        store.addCategory(TVCategory);


        Category tabletsCategory = new Category("Tablets");
        tabletsCategory.addProduct(new Product("Ipad 9", 800.0, 5));
        tabletsCategory.addProduct(new Product("Samsung A30", 500.0, 4));
        tabletsCategory.addProduct(new Product("Oppo Tablet S20", 450.0, 4));
        tabletsCategory.addProduct(new Product("Huawei Tablet H10 ", 340.0, 3));
        tabletsCategory.addProduct(new Product("Huawei Tablet H50 ", 490.0, 4));

        store.addCategory(tabletsCategory);

        ArrayList<User> users = new ArrayList<>();


        User user = new User("user", "user");
        User admin = new User("admin", "admin");
        while (true) {
            System.out.println("Welcome to our site! Please join your account.");
            System.out.println("1. Login as Admin");
            System.out.println("2. Login as User");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 1) {
                System.out.print("Enter admin username: ");
                String adminUsername = scanner.nextLine();
                System.out.print("Enter admin password: ");
                String adminPassword = scanner.nextLine();

                if (adminUsername.equals(admin.getLogin()) && adminPassword.equals(admin.getPass())) {
                    System.out.println("Join in admin account!");
                    while (true) {
                        System.out.println("Menu:");
                        System.out.println("1.Add new categories");
                        System.out.println("2.Add new product");
                        System.out.println("3.Delete product");
                        System.out.println("4.View all products and categories");
                        System.out.println("5.Delete category");
                        System.out.println("6.Exit");

                        int adminChoice = scanner.nextInt();
                        scanner.nextLine();
                        if (adminChoice == 1) {
                            System.out.print("Write a category name: ");
                            String cname = scanner.nextLine();
                            store.addCategory(new Category(cname));
                        } else if (adminChoice == 2) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("No categories available. Please add a category first.");
                            } else {
                                System.out.println("Exists categories:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    System.out.println((i + 1) + ". " + store.getCategories().get(i).getName());
                                }
                                System.out.print("Enter category number to add product to: ");
                                int cId = scanner.nextInt();
                                scanner.nextLine();
                                if (cId < 1 || cId > store.getCategories().size()) {
                                    System.out.println("Wrong category number.");
                                } else {
                                    Category sproduct = store.getCategories().get(cId - 1);
                                    System.out.print("Enter product name: ");
                                    String pname = scanner.nextLine();
                                    System.out.print("Enter product price: ");
                                    double pprice = scanner.nextDouble();
                                    System.out.print("Enter product rating: ");
                                    int prating = scanner.nextInt();
                                    sproduct.addProduct(new Product(pname, pprice, prating));
                                }
                            }
                        }

                        if (adminChoice == 3) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("There is no category. Please add a category first.");
                            } else {
                                System.out.println("Exists categories:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    System.out.println((i + 1) + ". " + store.getCategories().get(i).getName());
                                }
                                System.out.print("Please select the number of the category to delete the item ");
                                int cId = scanner.nextInt();
                                scanner.nextLine();
                                if (cId < 1 || cId > store.getCategories().size()) {
                                    System.out.println("Wrong number.");
                                } else {
                                    Category scategory = store.getCategories().get(cId - 1);
                                    System.out.println("Сurrent products:");
                                    for (int i = 0; i < scategory.getProducts().size(); i++) {
                                        System.out.println((i + 1) + ". " + scategory.getProducts().get(i).getName());
                                    }
                                    System.out.print("Write product number to delete: ");
                                    int pId = scanner.nextInt();
                                    if (pId < 1 || pId > scategory.getProducts().size()) {
                                        System.out.println("Wrong product number.");
                                    } else {
                                        Product sproduct = scategory.getProducts().get(pId - 1);
                                        scategory.removeProduct(sproduct);
                                        System.out.println("Product deleted successfully!");
                                    }
                                }
                            }
                        }
                        if (adminChoice == 4) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("Categories dont exists.");
                            } else {
                                System.out.println("Current categories and products:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    Category category = store.getCategories().get(i);
                                    System.out.println("Category: " + category.getName());
                                    category.sortProducts();
                                    for (Product product : category.getProducts()) {
                                        System.out.println("- " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                    }
                                }
                            }


                        }
                        if (adminChoice == 5) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("Categories dont exists.");
                            } else {
                                System.out.println("Current categories:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    Category category = store.getCategories().get(i);
                                    System.out.println((i + 1) + ". " + category.getName());
                                }

                                System.out.println("Enter the number of the category you want to delete:");
                                Scanner cn = new Scanner(System.in);
                                int cN = scanner.nextInt();

                                if (cN > 0 && cN <= store.getCategories().size()) {
                                    Category categoryToRemove = store.getCategories().get(cN - 1);
                                    store.removeCategory(categoryToRemove);
                                    System.out.println("Category " + categoryToRemove.getName() + " has been removed.");
                                } else {
                                    System.out.println("Invalid category number.");
                                }
                            }
                        } else if (adminChoice == 6) {
                            System.out.println("Exit");
                            System.out.println("Thank you for using our site!");
                            System.exit(0);
                        }
                        if (adminChoice != 5 && adminChoice != 4 && adminChoice != 3 && adminChoice != 2 && adminChoice != 1 && adminChoice != 6) {
                            System.out.println("Your choice is wrong");
                        }
                    }
                }
            }
            if (choice == 2) {
                System.out.print("Enter user username: ");
                String userUsername = scanner.nextLine();
                System.out.print("Enter user password: ");
                String userPassword = scanner.nextLine();

                if (userUsername.equals(user.getLogin()) && userPassword.equals(user.getPass())) {

                    System.out.println("Join in  user account");
                    while (true) {
                        System.out.println("Menu:");
                        System.out.println("1.View all products(categories and products) ");
                        System.out.println("2. Add product to the basket");
                        System.out.println("3. List of products in basket");
                        System.out.println("4. Delete product from the basket");
                        System.out.println("5. Pay for products in basket");
                        System.out.println("6. Search products");
                        System.out.println("7. Filter products by price");
                        System.out.println("8. Filter products by rating");
                        System.out.println("9. Exit");

                        System.out.print("Enter your choice: ");
                        int userchoice = scanner.nextInt();
                        scanner.nextLine();

                        if (userchoice == 1) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("Categories dont exists available.");
                            } else {
                                System.out.println("Current categories and products:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    Category category = store.getCategories().get(i);
                                    System.out.println("Category: " + category.getName());
                                    category.sortProducts();
                                    for (Product product : category.getProducts()) {
                                        System.out.println("- " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                    }
                                }
                            }
                        }
                        if (userchoice == 2) {
                            if (store.getCategories().isEmpty()) {
                                System.out.println("Categories dont exists.");
                            } else {
                                System.out.println("Current categories:");
                                for (int i = 0; i < store.getCategories().size(); i++) {
                                    System.out.println((i + 1) + ". " + store.getCategories().get(i).getName());
                                }
                                System.out.print("Write of category number: ");
                                int cId = scanner.nextInt();
                                scanner.nextLine();
                                if (cId < 1 || cId > store.getCategories().size()) {
                                    System.out.println("Wrong category number.");
                                } else {
                                    Category scategory = store.getCategories().get(cId - 1);
                                    System.out.println("Current products in " + scategory.getName() + ":");
                                    scategory.sortProducts();
                                    for (int i = 0; i < scategory.getProducts().size(); i++) {
                                        Product product = scategory.getProducts().get(i);
                                        System.out.println((i + 1) + ". " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                    }
                                    System.out.print("Write product number to added to the basket: ");
                                    int pId = scanner.nextInt();
                                    scanner.nextLine();
                                    if (pId < 1 || pId > scategory.getProducts().size()) {
                                        System.out.println("Wrong product number.");
                                    } else {
                                        Product sproduct = scategory.getProducts().get(pId - 1);
                                        user.getBasket().addProduct(sproduct);
                                        System.out.println(sproduct.getName() + " added in basket.");
                                    }
                                }
                            }
                        }

                        if (userchoice == 3) {
                            System.out.println("List of products in your basket:");
                            for (Product product : user.getBasket().getProducts()) {
                                System.out.println("- " + product.getName() + " - $" + product.getPrice());
                            }

                        }
                        if (userchoice == 4) {
                            System.out.println("List of products in your basket:");
                            for (int i = 0; i < user.getBasket().getProducts().size(); i++) {
                                Product product = user.getBasket().getProducts().get(i);
                                System.out.println((i + 1) + ". " + product.getName() + " - $" + product.getPrice());
                            }

                            System.out.print("Write the product number to remove from the basket: ");
                            int pId = scanner.nextInt();
                            scanner.nextLine();

                            if (pId < 1 || pId > user.getBasket().getProducts().size()) {
                                System.out.println("Wrong product number.");
                            } else {
                                Product sproduct = user.getBasket().getProducts().get(pId - 1);
                                user.getBasket().removeProduct(sproduct);
                                System.out.println(sproduct.getName() + " removed from the basket.");
                            }
                        }
                        if (userchoice == 5) {
                            double totalCost = 0;
                            System.out.println("Products in your basket:");
                            for (Product product : user.getBasket().getProducts()) {
                                System.out.println("- " + product.getName() + " - $" + product.getPrice());
                                totalCost += product.getPrice();
                            }
                            System.out.println("Total cost" + totalCost);

                            System.out.print("Enter the amount paid: $");
                            double amountPaid = scanner.nextDouble();
                            scanner.nextLine();

                            double change = amountPaid - totalCost;

                            LocalDateTime now = LocalDateTime.now();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                            String formattedDateTime = now.format(formatter);

                            System.out.println("Total cost: $" + totalCost);
                            System.out.println("Amount paid: $" + amountPaid);
                            System.out.println("Change: $" + change);
                            System.out.println("Date and time: " + formattedDateTime);
                            System.out.println("Thank you for your payment!");

                            user.getBasket().getProducts().clear();
                        }

                        if (userchoice == 6) {
                            System.out.print("Enter product, category name or price: ");
                            String query = scanner.nextLine();
                            ArrayList<Product> searchResults = store.search(query);
                            if (searchResults.isEmpty()) {
                                System.out.println("No products or categories found with the given name or price.");
                            } else {
                                System.out.println("Search results:");
                                for (Product product : searchResults) {
                                    System.out.println("- " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                }
                            }

                        } else if (userchoice == 7) {
                            System.out.print("Enter minimum price: ");
                            double minPrice = scanner.nextDouble();
                            System.out.print("Enter maximum price: ");
                            double maxPrice = scanner.nextDouble();

                            ArrayList<Product> filteredProducts = store.filterByPrice(minPrice, maxPrice);

                            if (filteredProducts.isEmpty()) {
                                System.out.println("No products found within the given price range.");
                            } else {
                                store.sortProducts(filteredProducts, "price");

                                System.out.println("Search results:");
                                for (Product product : filteredProducts) {
                                    System.out.println("- " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                }
                            }


                        } else if (userchoice == 8) {
                            System.out.print("Enter minimum rating: ");
                            int minRating = scanner.nextInt();
                            System.out.print("Enter maximum rating: ");
                            int maxRating = scanner.nextInt();

                            ArrayList<Product> filteredProducts = store.filterByRating(minRating, maxRating);

                            if (filteredProducts.isEmpty()) {
                                System.out.println("No products found within the given rating range.");
                            } else {
                                store.sortProducts(filteredProducts, "rating");

                                System.out.println("Search results:");
                                for (Product product : filteredProducts) {
                                    System.out.println("- " + product.getName() + " - $" + product.getPrice() + " (Rating: " + product.getRating() + ")");
                                }
                            }
                        }

                        if (userchoice == 9) {
                            System.out.println("Exit");
                            System.out.println("Thank you for using our site!");
                            System.exit(0);

                        }
                        if (userchoice != 5 && userchoice != 4 && userchoice != 3 && userchoice != 2 && userchoice != 1 && userchoice != 6 && userchoice != 7 && userchoice != 8 && userchoice != 9) {
                            System.out.println("Your choice is wrong");
                            //Tangirbergen Merei IT1-2208 LAB6 OOP
                        }
                    }

                }
            }
            else if (choice == 3) {
                System.out.println("Exiting.....");
                System.out.println("Thank you for using our site!");
                System.exit(0);
            }
            if (choice != 1 && choice != 2 && choice != 3) {
                System.out.println("Your choice is wrong");
                //Tangirbergen Merei IT1-2208 LAB6 OOP
            }
        }
    }

    }





















